#!/usr/bin/bash

wget https://repo.anaconda.com/archive/Anaconda3-2024.02-1-Linux-x86_64.sh
chmod +x Anaconda3-2024.02-1-Linux-x86_64.sh
sh Anaconda3-2024.02-1-Linux-x86_64.sh -y
sudo apt install git
git clone https://github.com/Qayam123/RAGGemmaModel.git
