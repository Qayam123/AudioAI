#!/bin/bash
chmod +x updupg.sh
chmod +x ollamaset.sh
chmod +x python.sh

./updupg.sh &
./ollamaset.sh &
./python.sh &

# Wait for all background processes to finish
wait
